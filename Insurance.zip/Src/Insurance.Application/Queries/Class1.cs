﻿namespace Insurance.Application.Queries
{
    public class Class1
    {

    }
}
