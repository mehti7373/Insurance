﻿using Insurance.Application.Interfaces;
using Insurance.Core.Interfaces;

namespace Insurance.Application.Commands.Users;

public class LoginCommandHandler(IUserRepository userRepository,ITokenService tokenService) : ICommandHandler<LoginCommand, LoginResult>
{
    public async Task<LoginResult> Handle(LoginCommand command, CancellationToken cancellationToken)
    {
        var user = await userRepository.GetByUsernameAsync(command.Username);
        if (user == null)
            throw new Exception("Invalid credentials");

        if (user.PasswordHash != HashPassword(command.Password))
            throw new Exception("Invalid credentials");

        var token = tokenService.GenerateToken(user.Username, user.Role);

        return new LoginResult(user.Username, token);
    }

    private string HashPassword(string password)
    {
        // Hashing logic (e.g., BCrypt)
        return password; // Placeholder
    }
}